import os
import json
from datetime import datetime
import paho.mqtt.client as mqtt
from influxdb_client import InfluxDBClient, Point, WritePrecision
from influxdb_client.client.write_api import SYNCHRONOUS

MQTT_BROKER = "mqtt_broker"
MQTT_PORT = 1883
MQTT_TOPIC = "#"

INFLUX_HOST = "http://influxdb:8086"
INFLUX_TOKEN = os.getenv("INFLUX_TOKEN", "your_token")
INFLUX_ORG = os.getenv("INFLUX_ORG", "my-org")
INFLUX_BUCKET = os.getenv("INFLUX_BUCKET", "iot_data")

DEBUG = os.getenv("DEBUG_DATA_FLOW", "false").lower() == "true"

import logging
logging.basicConfig(level=logging.DEBUG if DEBUG else logging.INFO)

influx_client = InfluxDBClient(url=INFLUX_HOST, token=INFLUX_TOKEN, org=INFLUX_ORG)
write_api = influx_client.write_api(write_options=SYNCHRONOUS)

def parse_message(topic, payload):
    try:
        data = json.loads(payload)
        timestamp = data.pop("timestamp", datetime.utcnow().isoformat())
        points = []

        for key, value in data.items():
            if isinstance(value, (int, float)):
                points.append(
                    Point(topic.replace("/", "."))
                    .field(key, value)
                    .time(timestamp, WritePrecision.NS)
                    .tag("location", topic.split("/")[0])
                )
        return points
    except Exception as e:
        logging.warning(f"Failed to parse message: {e}")
        return []

def on_message(client, userdata, msg):
    logging.info(f"Received message on topic {msg.topic}")
    points = parse_message(msg.topic, msg.payload.decode())
    if points:
        write_api.write(bucket=INFLUX_BUCKET, org=INFLUX_ORG, record=points)
        logging.info(f"Inserted {len(points)} points into InfluxDB")

mqtt_client = mqtt.Client()
mqtt_client.on_message = on_message
mqtt_client.connect(MQTT_BROKER, MQTT_PORT)
mqtt_client.subscribe(MQTT_TOPIC)

logging.info("MQTT to InfluxDB Adaptor started...")
mqtt_client.loop_forever()
